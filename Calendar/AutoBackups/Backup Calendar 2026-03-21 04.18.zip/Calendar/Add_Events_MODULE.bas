﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Activity
Version=13.4
@EndOfDesignText@
#Region  Activity Attributes 
	#FullScreen: False
	#IncludeTitle: True
#End Region

Sub Process_Globals
	'These global variables will be declared once when the application starts.
	'These variables can be accessed from all modules.
	Dim eventtype As String 
End Sub

Sub Globals
	'These global variables will be redeclared each time the activity is created.
	'These variables can only be accessed from this module.

End Sub

Sub Activity_Create(FirstTime As Boolean)
	'Do not forget to load the layout file created with the visual designer. For example:
	'Activity.LoadLayout("Layout1")
	Activity.LoadLayout("Layout5")

End Sub

Sub Activity_Resume
	If eventtype = "Event" Then
		
	Else if eventtype = "Task" Then
		
	Else if eventtype = "Birthday" Then
		
	Else if eventtype = "OOO" Then
		
	End If
End Sub

Sub Activity_Pause (UserClosed As Boolean)

End Sub


Private Sub x_btn_Click
	
End Sub

Private Sub save_btn_Click
	
End Sub

Private Sub ooorb_CheckedChange(Checked As Boolean)
	
End Sub

Private Sub birthdayrb_CheckedChange(Checked As Boolean)
	
End Sub

Private Sub eventrb_CheckedChange(Checked As Boolean)
	
End Sub

Private Sub taskrb_CheckedChange(Checked As Boolean)
	
End Sub