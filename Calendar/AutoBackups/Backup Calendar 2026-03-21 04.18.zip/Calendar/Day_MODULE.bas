﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Activity
Version=13.4
@EndOfDesignText@
#Region  Activity Attributes 
	#FullScreen: False
	#IncludeTitle: True
#End Region

Sub Process_Globals
	'These global variables will be declared once when the application starts.
	'These variables can be accessed from all modules.
	Dim currentDate As String
	Dim schedules As Map
End Sub

Sub Globals
	'These global variables will be redeclared each time the activity is created.
	'These variables can only be accessed from this module.

	Private Day_btn As Button
	Private menupanel As Panel
	Private Svtimeline As ScrollView
	Private date_todaylbl As Label
	Private addpanel As Panel
	Private Addtask_btn As Button
End Sub

Sub Activity_Create(FirstTime As Boolean)
	'Do not forget to load the layout file created with the visual designer. For example:
	'Activity.LoadLayout("Layout1")
	Activity.LoadLayout("Layout3")
	
	Day_btn.Color = Colors.blue
	date_todaylbl.Text = SetDate(currentDate)
	
	DrawHourLabels

End Sub

Sub SaveCalendar
	Main.kvs.put("CalendarKVS", Main.CalendarMap)
End Sub

Sub DrawHourLabels()
	
	Svtimeline.Panel.RemoveAllViews
	
	Dim rowh As Int = 60dip
	
	Svtimeline.Panel.Height = 24 * rowh
	Svtimeline.Panel.Width = Svtimeline.width
	
	For h = 0 To 23
		Dim lbl As Label
		lbl.Initialize("")
		lbl.Text = h & ":00"
		lbl.Gravity = Gravity.CENTER_VERTICAL
		Svtimeline.Panel.AddView(lbl, 0, h*rowh, 50dip, rowh)
	Next
End Sub

Sub SetDate(Tagdate As String) As String
	
	Dim parts() As String = Regex.Split("-", Tagdate)
	Dim year As String = parts(0)
	Dim monthNum As Int = parts(1)
	Dim day As String = parts(2)
	
	Dim monthName As String
	Select monthNum
		Case 1: monthName = "January"
		Case 2: monthName = "February"
		Case 3: monthName = "March"
		Case 4: monthName = "April"
		Case 5: monthName = "May"
		Case 6: monthName = "June"
		Case 7: monthName = "July"
		Case 8: monthName = "August"
		Case 9: monthName = "September"
		Case 10: monthName = "October"
		Case 11: monthName = "November"
		Case 12: monthName = "December"
	End Select
	
	Dim ts As Long = DateTime.DateParse(Tagdate)
	Dim weekdayNum As Int = DateTime.GetDayOfWeek(ts)
	Dim week As String
	Select weekdayNum
		Case 1: week = "Sunday"
		Case 2: week = "Monday"
		Case 3: week = "Tuesday"
		Case 4: week = "Wednesday"
		Case 5: week = "Thursday"
		Case 6: week = "Friday"
		Case 7: week = "Saturday"
	End Select
	
	Return week & ", " & monthName & " " & day & ", " & year
End Sub

Sub Activity_Resume

End Sub

Sub Activity_Pause (UserClosed As Boolean)

End Sub


Private Sub menu_btn_Click
	menupanel.Visible =True
End Sub

Private Sub sched_btn_Click
	Activity.Finish
	StartActivity(Schedule_MODULE)
End Sub

Private Sub Day_btn_Click
	menupanel.Visible = False
End Sub

Private Sub Week_btn_Click
	Activity.Finish
	StartActivity(Week_MODULE)
End Sub

Private Sub Month_btn_Click
	Activity.Finish
	StartActivity(Main)
End Sub

Private Sub Addevent_btn_Click
	addpanel.Visible = False
	Add_Events_MODULE.eventtype = "Event"
End Sub

Private Sub addnew_btn_Click
	addpanel.Visible = True
	
	If addpanel.Visible =True Then
		addpanel.Visible = False
	End If
End Sub

Private Sub Addtask_btn_Click
	addpanel.Visible = False
	Add_Events_MODULE.eventtype = "Task"
End Sub

Private Sub birthday_btn_Click
	addpanel.Visible = False
	Add_Events_MODULE.eventtype = "Birthday"
End Sub

Private Sub ooo_btn_Click
	addpanel.Visible = False
	Add_Events_MODULE.eventtype = "OOO"
End Sub