﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Activity
Version=13.4
@EndOfDesignText@
#Region  Activity Attributes 
	#FullScreen: False
	#IncludeTitle: True
#End Region

Sub Process_Globals
	'These global variables will be declared once when the application starts.
	'These variables can be accessed from all modules.
	Dim currentDate As String
	Dim schedules As Map
End Sub

Sub Globals
	'These global variables will be redeclared each time the activity is created.
	'These variables can only be accessed from this module.

	Private Day_btn As Button
	Private menupanel As Panel
	Private Svtimeline As ScrollView
End Sub

Sub Activity_Create(FirstTime As Boolean)
	'Do not forget to load the layout file created with the visual designer. For example:
	'Activity.LoadLayout("Layout1")
	Activity.LoadLayout("Layout3")
	
	Day_btn.Color = Colors.blue
	
	DrawHourLabels

End Sub

Sub DrawHourLabels()
	
	Svtimeline.Panel.RemoveAllViews
	
	Dim rowh As Int = 60dip
	
	Svtimeline.Panel.Height = 24 * rowh
	Svtimeline.Panel.Width = Svtimeline.width
	
	For h = 0 To 23
		Dim lbl As Label
		lbl.Initialize("")
		lbl.Text = h & ":00"
		lbl.Gravity = Gravity.CENTER_VERTICAL
		Svtimeline.Panel.AddView(lbl, 0, h*rowh, 50dip, rowh)
	Next
End Sub

Sub Activity_Resume

End Sub

Sub Activity_Pause (UserClosed As Boolean)

End Sub


Private Sub menu_btn_Click
	menupanel.Visible =True
End Sub

Private Sub sched_btn_Click
	Activity.Finish
	StartActivity(Schedule_MODULE)
End Sub

Private Sub Day_btn_Click
	menupanel.Visible = False
End Sub

Private Sub Week_btn_Click
	Activity.Finish
	StartActivity(Week_MODULE)
End Sub

Private Sub Month_btn_Click
	Activity.Finish
	StartActivity(Main)
End Sub