﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Activity
Version=13.4
@EndOfDesignText@
#Region  Activity Attributes 
	#FullScreen: False
	#IncludeTitle: True
#End Region

Sub Process_Globals
	'These global variables will be declared once when the application starts.
	'These variables can be accessed from all modules.

End Sub

Sub Globals
	'These global variables will be redeclared each time the activity is created.
	'These variables can only be accessed from this module.

	Private menupanel As Panel
	Private sched_btn As Button
	Private scheduleSV As ScrollView
End Sub

Sub Activity_Create(FirstTime As Boolean)
	'Do not forget to load the layout file created with the visual designer. For example:
	'Activity.LoadLayout("Layout1")
	Activity.LoadLayout("Layout4")
	
	sched_btn.Color = Colors.blue

End Sub

Sub DrawSchedule
	scheduleSV.Panel.RemoveAllViews
	
	Dim y As Int = 0
	Dim sortedDates As List
	
	For Each keys As String In Main.CalendarMap.Keys
		sortedDates.Add(keys)
	Next
	
	sortedDates.Sort(True)
	
	For Each date As String In sortedDates
		Dim lbldate As Label
		lbldate.initialize("")
		lbldate.Text = SetDate(date)
		lbldate.TextSize = 16
		lbldate.Color = Colors.LightGray
		lbldate.TextColor = Colors.Black
	
		scheduleSV.Panel.AddView(lbldate, 0, y, scheduleSV.Width, 40dip)
		Dim eventmap As Map = Main.CalendarMap.Get(date)
		Dim allevents As List = eventmap.Get("AllEvents")
		
		For Each ev As Map In allevents
			Dim lbl As Label
			lbl.Initialize("")
			lbl.Text = ev.Get(
		Next
		
		Dim timeline As List = eventmap.Get("Timeline")
		
	Next
End Sub


Sub SetDate(Tagdate As String) As String
	
	Dim parts() As String = Regex.Split("-", Tagdate)
	Dim year As String = parts(0)
	Dim monthNum As Int = parts(1)
	Dim day As String = parts(2)
	
	Dim monthName As String
	Select monthNum
		Case 1: monthName = "January"
		Case 2: monthName = "February"
		Case 3: monthName = "March"
		Case 4: monthName = "April"
		Case 5: monthName = "May"
		Case 6: monthName = "June"
		Case 7: monthName = "July"
		Case 8: monthName = "August"
		Case 9: monthName = "September"
		Case 10: monthName = "October"
		Case 11: monthName = "November"
		Case 12: monthName = "December"
	End Select
	
	Dim ts As Long = DateTime.DateParse(Tagdate)
	Dim weekdayNum As Int = DateTime.GetDayOfWeek(ts)
	Dim week As String
	Select weekdayNum
		Case 1: week = "Sunday"
		Case 2: week = "Monday"
		Case 3: week = "Tuesday"
		Case 4: week = "Wednesday"
		Case 5: week = "Thursday"
		Case 6: week = "Friday"
		Case 7: week = "Saturday"
	End Select
	
	Return week & ", " & monthName & " " & day & ", " & year
End Sub

Sub Activity_Resume

End Sub

Sub Activity_Pause (UserClosed As Boolean)

End Sub

Private Sub menu_btn_Click
	menupanel.Visible =True
End Sub


Private Sub sched_btn_Click
	menupanel.visible = False
End Sub

Private Sub Day_btn_Click
	Dim currentyear As Int = DateTime.GetYear(DateTime.Now)
	Dim currentmonth As Int = DateTime.GetMonth(DateTime.Now)
	Dim currentday As Int = DateTime.GetDayOfMonth(DateTime.Now)
	Day_MODULE.currentDate = currentyear & "-" & currentmonth & "-" & currentday
	Activity.Finish
	StartActivity(Day_MODULE)
End Sub

Private Sub Week_btn_Click
	Activity.Finish
	StartActivity(Week_MODULE)
End Sub

Private Sub Month_btn_Click
	Activity.Finish
	StartActivity(Main)
End Sub