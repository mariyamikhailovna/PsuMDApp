﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Activity
Version=13.4
@EndOfDesignText@
#Region  Activity Attributes 
	#FullScreen: False
	#IncludeTitle: True
#End Region

Sub Process_Globals
	'These global variables will be declared once when the application starts.
	'These variables can be accessed from all modules.

End Sub

Sub Globals
	'These global variables will be redeclared each time the activity is created.
	'These variables can only be accessed from this module.
	Private LastX, LastY As Float
	Private boardPnl As Panel
	Private addPnl As Panel
	Private canvaBtn As Button
	Private imgBtn As Button
	Private stickyBtn As Button
	Private stringBtn As Button
	Private stickyTxt As  EditText
End Sub

Sub Activity_Create(FirstTime As Boolean)
	Activity.LoadLayout("corkboardLayout")

End Sub

Sub Activity_Resume

End Sub

Sub Activity_Pause (UserClosed As Boolean)

End Sub

'THINGS TO ADD
'1. Sticky Notes
'2. Images
'3. Canvas
'4. String
'5. Being able to hide add buttons

Sub AddStickyNote(Text As String, x As Int, y As Int)
	Dim p As Panel
	p.Initialize("Sticky")
	p.Color = Colors.RGB(255, 255, 150) ' Classic yellow
    
	Dim lbl As Label
	lbl.Initialize("")
	lbl.Text = Text
	p.AddView(lbl, 10dip, 10dip, 80dip, 80dip)
    
	boardPnl.AddView(p, x, y, 100dip, 100dip)
	
	stickyTxt.Initialize("stickyTxt")
	stickyTxt.Background = Null
	stickyTxt.TextSize = 9
	stickyTxt.Gravity = Gravity.TOP
	stickyTxt.Hint = "Notes.."
	p.AddView(stickyTxt, 5dip, 5dip, 80dip, 80dip)
End Sub

' The logic for dragging items
Sub Sticky_Touch (Action As Int, X As Float, Y As Float)
	Dim v As B4XView = Sender

	Select Action
		Case 0 ' Down
			LastX = X
			LastY = Y
			v.BringToFront
		Case 2 ' Move
			v.Left = v.Left + X - LastX
			v.Top = v.Top + Y - LastY
	End Select
End Sub

Private Sub stickyBtn_Click
	AddStickyNote("", 100, 100)
End Sub