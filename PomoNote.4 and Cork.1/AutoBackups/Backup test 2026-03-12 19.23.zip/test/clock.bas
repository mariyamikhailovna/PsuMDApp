﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Activity
Version=13.4
@EndOfDesignText@
#Region  Activity Attributes 
	#FullScreen: False
	#IncludeTitle: True
#End Region

Sub Process_Globals
	'These global variables will be declared once when the application starts.
	'These variables can be accessed from all modules.
	Private timerCount As Timer
	Private secondsRemain As Int = 5

End Sub

Sub Globals
	'These global variables will be redeclared each time the activity is created.
	'These variables can only be accessed from this module.
	Private pomotimerLbl As Label
	Private playBtn As Button
	Private pomoCounter As Label
	Private pomoTxt As EditText
	Private shortTxt As EditText
	Private longTxt As EditText
	Dim timerState As Int = 0
	Dim counter As Int = 0
	Dim pomoDef As Int = 5
	Dim shortDef As Int = 3
	Dim longDef As Int = 7

End Sub

Sub Activity_Create(FirstTime As Boolean)
	Activity.LoadLayout("clockLayout")
	If FirstTime Then
		timerCount.Initialize("tmr", 1000)
	End If
	
	timerCount.Enabled = False
	updateLbl
	pomoCounter.Text = counter
End Sub

Sub Activity_Resume

End Sub

Sub Activity_Pause (UserClosed As Boolean)

End Sub

Private Sub exitBtn_Click
	Activity.Finish
End Sub

Private Sub formatBtn_Click
	
	Main.format24h = Not(Main.format24h)
	
	If Main.format24h Then
		DateTime.TimeFormat = "HH:mm:ss"
	Else
		DateTime.TimeFormat = "hh:mm:ss a"
	End If
	CallSub(Main, "timerClock_Tick")
	
End Sub

Private Sub playBtn_Click
	If secondsRemain > 0 Then
		timerCount.Enabled = True
		playBtn.Enabled = False
	End If
End Sub

Sub tmr_Tick
	If secondsRemain > 0 Then
		secondsRemain = secondsRemain - 1
		updateLbl
	Else
		timerCount.Enabled = False
		playBtn.Enabled = True
		
		
		If timerState = 0 Then
			counter = counter + 1
			
			If counter Mod 4 = 0 Then
				secondsRemain = longDef 
			Else
				secondsRemain = shortDef 
			End If
			timerState = 1 
        
		Else If timerState = 1 Then
			secondsRemain = pomoDef
			timerState = 0
		End If
    
		updateLbl
	End If
End Sub

Sub updateLbl
	Dim mins As Int = secondsRemain / 60
	Dim secs As Int = secondsRemain Mod 60
	pomotimerLbl.Text = $"$02.0{mins}:$02.0{secs}"$
	pomoCounter.Text = counter
End Sub

Private Sub pomoBtn_Click
	secondsRemain = pomoDef
	timerState = 0
	updateLbl
End Sub

Private Sub shortBtn_Click
	secondsRemain = shortDef
	timerState = 1
	updateLbl
End Sub

Private Sub longBtn_Click
	secondsRemain = longDef
	timerState = 1
	updateLbl
End Sub

Private Sub pomoTxt_TextChanged (Old As String, New As String)
	po
End Sub