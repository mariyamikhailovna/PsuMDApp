﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Activity
Version=13.4
@EndOfDesignText@
#Region  Activity Attributes 
	#FullScreen: False
	#IncludeTitle: True
#End Region

Sub Process_Globals
	'These global variables will be declared once when the application starts.
	'These variables can be accessed from all modules.
	Private xui As XUI
End Sub

Sub Globals
	'These global variables will be redeclared each time the activity is created.
	'These variables can only be accessed from this module.
	Private notePnl As B4XView
	Private addBtn As Button
	Private noteTxt As EditText
End Sub

Sub Activity_Create(FirstTime As Boolean)
	Activity.LoadLayout("notepadLayout")

End Sub

Sub Activity_Resume

End Sub

Sub Activity_Pause (UserClosed As Boolean)

End Sub

Private Sub panelMake(pW As Int, pH As Int)
	notePnl = xui.CreatePanel("notePnl")
	notePnl = xui.CreatePanel("settingsPnl")
	Activity.AddView(notePnl, 100, 20, pW, pH)
	notePnl.Color = xui.Color_RGB(50, 50, 50)
	notePnl.SetColorAndBorder(xui.Color_White, 2dip, xui.Color_Black, 3dip)
	notePnl.Enabled = False
	notePnl.Visible = False
	
	
End Sub

Private Sub addBtn_Click
	panelMake(300dip,700dip)
	notePnl.Visible = True
End Sub
