﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Activity
Version=13.4
@EndOfDesignText@
#Region  Activity Attributes 
	#FullScreen: False
	#IncludeTitle: True
#End Region

Sub Process_Globals
	'These global variables will be declared once when the application starts.
	'These variables can be accessed from all modules.
	Private xui As XUI
	Type notepad (Title As String, Tags As String, Content As String, DateAdded As Long)
End Sub

Sub Globals
	'These global variables will be redeclared each time the activity is created.
	'These variables can only be accessed from this module.
	Private notePnl As B4XView
	Private addBtn As Button
	Private noteTxt As EditText
	Private noteCvl As CustomListView
End Sub

Sub Activity_Create(FirstTime As Boolean)
	Activity.LoadLayout("notepadLayout")

End Sub

Sub Activity_Resume
	RefreshList
End Sub

Sub Activity_Pause (UserClosed As Boolean)

End Sub

Sub RefreshList
	noteCvl.Clear
	' Loop through all keys in KVS that start with "Note_"
	Dim keys As List = Main.kvs.ListKeys
	For Each k As String In keys
		If k.StartsWith("Note_") Then
			Dim n As MyNote = Main.kvs.Get(k)
			' Add to list (Title and Tags shown in the list)
			noteCvl.AddTextItem(n.Title & CRLF & n.Tags, n)
		End If
	Next
End Sub

Sub addBtn_Click
	' Open the screen to write a new note
	StartActivity(editnote)
End Sub

Sub noteCvl_ItemClick (Index As Int, Value As Object)
	' Value is the MyNote object we stored.
	' You could use this to open an existing note to edit it.
End Sub


'Private Sub panelMake(pW As Int, pH As Int)
'	notePnl = xui.CreatePanel("notePnl")
'	notePnl = xui.CreatePanel("settingsPnl")
'	Activity.AddView(notePnl, 70dip, 20dip, pW, pH)
'	notePnl.Color = xui.Color_RGB(50, 50, 50)
'	notePnl.SetColorAndBorder(xui.Color_White, 2dip, xui.Color_Black, 3dip)
'	notePnl.Enabled = False
'	notePnl.Visible = False
'	
'	noteTxt.Initialize("noteTxt")
'	noteTxt.Hint = "Notepad"
'	noteTxt.Background = Null
'	notePnl.AddView(noteTxt, 20dip, 20dip, 200dip, 600dip)
'End Sub
'
'Private Sub addBtn_Click
'	panelMake(300dip,700dip)
'	notePnl.Visible = True
'End Sub
