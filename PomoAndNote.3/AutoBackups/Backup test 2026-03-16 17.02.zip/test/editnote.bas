﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Activity
Version=13.4
@EndOfDesignText@
#Region  Activity Attributes 
	#FullScreen: False
	#IncludeTitle: True
#End Region

Sub Process_Globals
	'These global variables will be declared once when the application starts.
	'These variables can be accessed from all modules.

End Sub

Sub Globals
	'These global variables will be redeclared each time the activity is created.
	'These variables can only be accessed from this module.

	Private contentTxt As EditText
	Private saveBtn As Button
	Private tagsTxt As EditText
	Private titleTxt As EditText
End Sub

Sub Activity_Create(FirstTime As Boolean)
	Activity.LoadLayout("editnoteLayout")
	tit.Background = Null
	etTags.Background = Null
	etContent.Background = Null
	etContent.Gravity = Bit.Or(Gravity.TOP, Gravity.LEFT)
End Sub

Sub Activity_Resume

End Sub

Sub Activity_Pause (UserClosed As Boolean)

End Sub
