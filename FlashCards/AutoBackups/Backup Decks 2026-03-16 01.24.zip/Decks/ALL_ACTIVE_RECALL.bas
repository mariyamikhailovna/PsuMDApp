﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Activity
Version=13.4
@EndOfDesignText@
#Region  Activity Attributes 
	#FullScreen: False
	#IncludeTitle: True
#End Region

Sub Process_Globals
	'These global variables will be declared once when the application starts.
	'These variables can be accessed from all modules.

End Sub

Sub Globals
	'These global variables will be redeclared each time the activity is created.
	'These variables can only be accessed from this module.
	Dim cards As List
	Dim currentindex As Int
	Private Question As Label
	Private Answer As Label
	Private DeckName_Label As Label
	Private showAnswerbtn As Button
End Sub

Sub Activity_Create(FirstTime As Boolean)
	'Do not forget to load the layout file created with the visual designer. For example:
	'Activity.LoadLayout("Layout1")
	Activity.LoadLayout("Layout5")
	
	cards.Initialize
	RndSeed(DateTime.Now)
	Dim chosendeck As Map = Main.deck.Get(Main.selecteddeck)
	For Each subdeckname As String In chosendeck.Keys
		Dim subcards As List = chosendeck.Get(subdeckname)
		For Each card As Map In subcards
			Dim newcard As Map 
			newcard.Initialize
			newcard.Put("Q", card.Get("Q"))
			newcard.Put("A", card.Get("A"))
			newcard.Put("subdeck", subdeckname)
			cards.Add(newcard)
		Next
	Next
	ShuffleCards(cards)
	currentindex = 0
	Showcard
End Sub

Sub ShuffleCards(cardList As List)
	For i = cardList.Size-1 To 1 Step -1
		Dim j As Int = Rnd(0, i+1)
		
		Dim temp As Object = cardList.Get(i)
		cardList.Set(i, cardList.Get(j))
		cardList.Set(j, temp)
	Next
End Sub

Sub Showcard
	Dim card As Map = cards.Get(currentindex)
	Question.Text = card.Get("Q")
	Answer.Text = ""
	DeckName_Label.Text = card.Get("subdeck")
End Sub

Sub Activity_Resume

End Sub

Sub Activity_Pause (UserClosed As Boolean)

End Sub


Private Sub showAnswerbtn_Click
	Dim card As Map = cards.Get(currentindex)
	If showAnswerbtn.Text = "Show Answer" Then 
		Answer.Text = card.Get("A")
		showAnswerbtn.Text = "Hide Answer"
		
	Else
		Answer.Text = ""
		showAnswerbtn.Text = "Show Answer"
	End If
End Sub

Private Sub backbtn_Click
	showAnswerbtn.Text = "Show Answer"
	if currentindex = 0
End Sub

Private Sub nextbtn_Click
	showAnswerbtn.Text = "Show Answer"
	currentindex = currentindex +1
	If currentindex >= cards.Size Then
		MsgboxAsync("Decks Finished", "Active Recall")
		Activity.finish
	End If
	
	Showcard
End Sub

Private Sub goback_Click
	Activity.finish
End Sub