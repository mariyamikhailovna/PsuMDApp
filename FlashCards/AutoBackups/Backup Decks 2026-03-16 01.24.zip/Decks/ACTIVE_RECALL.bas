﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Activity
Version=13.4
@EndOfDesignText@
#Region  Activity Attributes 
	#FullScreen: False
	#IncludeTitle: True
#End Region

Sub Process_Globals
	'These global variables will be declared once when the application starts.
	'These variables can be accessed from all modules.

End Sub

Sub Globals
	'These global variables will be redeclared each time the activity is created.
	'These variables can only be accessed from this module.

	Private DeckName_Label As Label
	Private Question As Label
	Private Answer As Label
	
	Dim cards As List
	Dim currentindex As Int
	Private showAnswerbtn As Button
End Sub

Sub Activity_Create(FirstTime As Boolean)
	'Do not forget to load the layout file created with the visual designer. For example:
	'Activity.LoadLayout("Layout1")
	Activity.LoadLayout("Layout5")
	
	Dim tappeddeck As Map = Main.deck.Get(Main.selecteddeck)
	cards = tappeddeck.Get(Subdeck_Module.selectedsubdeck)
	
	currentindex = 0
	DeckName_Label.text = Subdeck_Module.selectedsubdeck
	
	
	ShowCard
	
End Sub

Sub ShowCard
	Dim card As Map = cards.Get(currentindex)
	Question.Text = card.Get("Q")
	Answer.Text = ""
End Sub

Sub Activity_Resume

End Sub

Sub Activity_Pause (UserClosed As Boolean)

End Sub


Private Sub showAnswerbtn_Click
	Dim card As Map = cards.Get(currentindex)
	If showAnswerbtn.Text = "Show Answer" Then
		Answer.Text = card.Get("A")
		showAnswerbtn.Text = "Hide Answer"
	Else
		Answer.Text = ""
		showAnswerbtn.Text = "Show Answer"
		
	End If
	
	
End Sub

Private Sub nextbtn_Click
	showAnswerbtn.Text = "Show Answer"
	currentindex = currentindex +1
	If currentindex >= cards.Size Then
		currentindex = 0
	End If
	ShowCard
End Sub

Private Sub goback_Click
	Activity.finish
End Sub

Private Sub backbtn_Click
	showAnswerbtn.Text = "Show Answer"
	currentindex = currentindex -1
	If currentindex < 0 Then
		 currentindex = cards.Size -1
	End If
	
	ShowCard
	
End Sub