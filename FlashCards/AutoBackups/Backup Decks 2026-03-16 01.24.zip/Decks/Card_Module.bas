﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Activity
Version=13.4
@EndOfDesignText@
#Region  Activity Attributes 
	#FullScreen: True
	#IncludeTitle: False
#End Region

Sub Process_Globals
	'These global variables will be declared once when the application starts.
	'These variables can be accessed from all modules.

End Sub

Sub Globals
	'These global variables will be redeclared each time the activity is created.
	'These variables can only be accessed from this module.

	Private subdecklabel As Label
	Private ScrollView1 As ScrollView
End Sub

Sub Activity_Create(FirstTime As Boolean)
	'Do not forget to load the layout file created with the visual designer. For example:
	'Activity.LoadLayout("Layout1")
	Activity.LoadLayout("Layout4")
	subdecklabel.Text = Subdeck_Module.selectedsubdeck
	
	Dim tappedDeck As Map = Main.deck.Get(Main.selecteddeck)
	Dim subdeckcards As List = tappedDeck.Get(Subdeck_Module.selectedsubdeck)
	
	ShowSubdeckCards(subdeckcards)
	
End Sub

Sub ShowSubdeckCards(cardsList As List)
	ScrollView1.Panel.RemoveAllViews
	Dim topPos As Int = 0
	Dim cardHeight As Int = 50dip
	
	For i = 0 To cardsList.Size -1
	Dim card As Map = cardsList.Get(i)
	Dim p As Panel
	p.Initialize("")
	p.Color = Colors.White
	ScrollView1.Panel.AddView(p, 10dip, topPos, ScrollView1.Width - 20dip, cardHeight)
	
		Dim lbl As Label
		lbl.Initialize("")
		lbl.Text = "Q: " & card.Get("Q") & " | A: " & card.Get("A")
		lbl.TextColor = Colors.black
		lbl.TextSize = 14
		lbl.SingleLine = False
		
		ScrollView1.Panel.AddView(lbl, 10dip, topPos, ScrollView1.Width - 20dip, cardHeight)
		topPos = topPos + lbl.height + 10dip
		
		Dim editbtn As Button 
		editbtn.Initialize("Editbtn")
		editbtn.Tag = i
		editbtn.Text = "Edit"
		p.AddView(editbtn, p.Width - 100dip, 10dip, 45dip, 25dip)
		
		Dim deletebtn As Button
		deletebtn.Initialize("Deletebtn")
		deletebtn.Tag = i
		deletebtn.Text = "Edit"
		p.AddView(deletebtn, p.Width - 100dip, 10dip, 45dip, 25dip)
	Next
	ScrollView1.Panel.Height = topPos + 10dip
End Sub

Sub editbtn_Click
	Dim b As Button = Sender
	Dim index As Int = b.Tag
	Dim tappedDeck As Map = Main.deck.Get(Main.selecteddeck)
	Dim cards As List = tappedDeck.Get(Subdeck_Module.selectedsubdeck)
	Dim card As Map = cards.Get(index)
	
	Log(card.Get("Q"))
	Log(card.Get("A"))
	
End Sub

Sub deletebtn_click
	
End Sub

Sub Activity_Resume

End Sub

Sub Activity_Pause (UserClosed As Boolean)

End Sub



Private Sub backbtn_Click
	Activity.Finish
End Sub

Private Sub activerecall_Click
	StartActivity(ACTIVE_RECALL)
End Sub